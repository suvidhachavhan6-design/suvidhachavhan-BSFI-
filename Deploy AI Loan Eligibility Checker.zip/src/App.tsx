import { useState, useCallback } from 'react'

/* ─── Types ─────────────────────────────────────────────── */
type Tab = 'eligibility' | 'credit' | 'emi' | 'tips'

interface LoanResult {
  eligible: boolean
  maxAmount: number
  interestRate: number
  reasons: string[]
  score: number
}

interface CreditResult {
  score: number
  rating: string
  factors: { label: string; impact: 'positive' | 'negative' | 'neutral'; value: string }[]
  advice: string[]
}

interface EmiResult {
  emi: number
  totalPayment: number
  totalInterest: number
  breakdown: { month: number; principal: number; interest: number; balance: number }[]
}

/* ─── Helpers ────────────────────────────────────────────── */
const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

const fmtNum = (n: number) =>
  new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(n)

function scoreColor(score: number) {
  if (score >= 750) return '#34d399'
  if (score >= 650) return '#fbbf24'
  if (score >= 550) return '#f97316'
  return '#fb7185'
}

function scoreLabel(score: number) {
  if (score >= 750) return 'Excellent'
  if (score >= 650) return 'Good'
  if (score >= 550) return 'Fair'
  return 'Poor'
}

/* ─── AI Simulation ──────────────────────────────────────── */
function analyzeLoanEligibility(data: {
  income: number; age: number; employment: string
  existing: number; loanAmount: number; loanType: string
}): LoanResult {
  const { income, age, employment, existing, loanAmount } = data
  const reasons: string[] = []
  let score = 100

  const dti = existing / income
  if (dti > 0.4) { score -= 30; reasons.push('Debt-to-income ratio exceeds 40% threshold') }
  else if (dti > 0.25) { score -= 15; reasons.push('Moderate existing debt obligations') }
  else reasons.push('Healthy debt-to-income ratio')

  if (age < 21 || age > 65) { score -= 25; reasons.push('Age outside preferred lending bracket (21–65)') }
  else if (age >= 25 && age <= 50) reasons.push('Age within optimal lending range')

  if (employment === 'self') { score -= 10; reasons.push('Self-employed applicants require additional documentation') }
  else if (employment === 'salaried') reasons.push('Stable salaried employment — positive indicator')

  const affordability = income * 60
  if (loanAmount > affordability) { score -= 20; reasons.push('Requested amount exceeds 60× monthly income') }
  else reasons.push('Loan amount within affordable range')

  if (income < 25000) { score -= 15; reasons.push('Monthly income below ₹25,000 minimum threshold') }
  else if (income >= 75000) reasons.push('Strong income profile')

  const eligible = score >= 60
  const maxAmount = Math.min(affordability, eligible ? loanAmount : loanAmount * (score / 100))
  const rate = employment === 'salaried' ? (score >= 80 ? 9.5 : 11.5) : (score >= 80 ? 11 : 13.5)

  return { eligible, maxAmount, interestRate: rate, reasons, score }
}

function analyzeCreditScore(data: {
  score: number; missedPayments: number; creditAge: number
  utilization: number; inquiries: number
}): CreditResult {
  const { score, missedPayments, creditAge, utilization, inquiries } = data
  const factors: CreditResult['factors'] = [
    {
      label: 'Payment History',
      impact: missedPayments === 0 ? 'positive' : missedPayments <= 2 ? 'neutral' : 'negative',
      value: missedPayments === 0 ? 'No missed payments' : `${missedPayments} missed payment${missedPayments > 1 ? 's' : ''}`
    },
    {
      label: 'Credit Utilization',
      impact: utilization <= 30 ? 'positive' : utilization <= 60 ? 'neutral' : 'negative',
      value: `${utilization}% utilization`
    },
    {
      label: 'Credit History Length',
      impact: creditAge >= 5 ? 'positive' : creditAge >= 2 ? 'neutral' : 'negative',
      value: `${creditAge} year${creditAge !== 1 ? 's' : ''}`
    },
    {
      label: 'Recent Inquiries',
      impact: inquiries <= 1 ? 'positive' : inquiries <= 3 ? 'neutral' : 'negative',
      value: `${inquiries} recent hard inqui${inquiries !== 1 ? 'ries' : 'ry'}`
    }
  ]

  const advice: string[] = []
  if (missedPayments > 0) advice.push('Set up auto-pay to prevent future missed payments — payment history is 35% of your score.')
  if (utilization > 30) advice.push(`Reduce credit utilization below 30% (currently ${utilization}%). Pay down revolving balances.`)
  if (inquiries > 3) advice.push('Limit new credit applications — each hard inquiry can drop your score by 5–10 points.')
  if (creditAge < 3) advice.push('Keep older accounts open to build a longer credit history.')
  if (score < 750) advice.push('Become an authorized user on a trusted family member\'s long-standing account.')

  return { score, rating: scoreLabel(score), factors, advice }
}

function calcEmi(principal: number, annualRate: number, months: number): EmiResult {
  const r = annualRate / 12 / 100
  const emi = r === 0 ? principal / months : (principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1)
  const totalPayment = emi * months
  const totalInterest = totalPayment - principal

  const breakdown: EmiResult['breakdown'] = []
  let balance = principal
  for (let m = 1; m <= Math.min(months, 12); m++) {
    const interest = balance * r
    const principalPart = emi - interest
    balance -= principalPart
    breakdown.push({ month: m, principal: principalPart, interest, balance: Math.max(0, balance) })
  }

  return { emi, totalPayment, totalInterest, breakdown }
}

/* ─── AI Tips (simulated streaming) ─────────────────────── */
const AI_TIPS: Record<string, string[]> = {
  savings: [
    '💡 The 50/30/20 rule: allocate 50% to needs, 30% to wants, 20% to savings and debt repayment.',
    '📈 A liquid emergency fund of 6× monthly expenses shields you from predatory high-interest borrowing.',
    '🏦 Recurring deposits with quarterly compounding outperform simple savings accounts by 0.8–1.2% annually.',
    '🔄 Automate transfers on salary day — behavioral research shows automation doubles saving consistency.',
    '📊 Segment savings into buckets: emergency, goals, investments. Single-pool savings get raided more often.',
  ],
  investment: [
    '📊 Equity mutual funds (ELSS) offer dual benefits: Section 80C tax deduction up to ₹1.5L + market-linked returns.',
    '🌱 SIP investments harness rupee-cost averaging — volatile markets lower your average purchase price over time.',
    '🏠 REITs provide real estate exposure from ₹10,000–₹15,000 with quarterly distributions and high liquidity.',
    '⚖️ Rebalance your portfolio annually — drift of 5%+ from target allocation meaningfully increases risk.',
    '🎯 Index funds beat 85% of actively managed funds over 10+ year horizons, at 10× lower expense ratios.',
  ],
  debt: [
    '🎯 The avalanche method (highest APR first) minimizes total interest paid — often saves ₹50,000–₹2L on multi-debt portfolios.',
    '💳 Credit card debt at 36–42% APR is the most expensive debt product in India. Prioritize full clearance monthly.',
    '🔄 Balance transfer to a 0% introductory card buys 6–12 months interest-free — use it as a debt reduction sprint.',
    '📉 Prepay home loans in the first 1/3 of tenure — each rupee prepaid saves roughly ₹2–3 in future interest.',
    '🛡️ Maintain a credit utilization below 30% — it raises your CIBIL score by 30–60 points within 2–3 months.',
  ],
  tax: [
    '🏛️ Maximize Section 80C (₹1.5L): PPF, ELSS, EPF, NSC, and home loan principal all qualify.',
    '🏥 Section 80D health insurance premiums offer ₹25,000–₹75,000 deduction depending on age and coverage.',
    '🏠 Home loan interest deductions under Section 24(b) can offset up to ₹2L of taxable income annually.',
    '📋 NPS Tier-I investments qualify for an additional ₹50,000 under Section 80CCD(1B) — beyond the 80C cap.',
    '📈 LTCG on equity exceeding ₹1.25L is taxed at 12.5%. Time asset sales to straddle the financial year if possible.',
  ],
}

/* ─── Sub-components ─────────────────────────────────────── */

function LoanEligibility() {
  const [form, setForm] = useState({
    income: '', age: '', employment: 'salaried', existing: '',
    loanAmount: '', loanType: 'home'
  })
  const [result, setResult] = useState<LoanResult | null>(null)
  const [loading, setLoading] = useState(false)

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const analyze = useCallback(async () => {
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 1200))
    const r = analyzeLoanEligibility({
      income: Number(form.income), age: Number(form.age),
      employment: form.employment, existing: Number(form.existing),
      loanAmount: Number(form.loanAmount), loanType: form.loanType
    })
    setResult(r)
    setLoading(false)
  }, [form])

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <InputField label="Monthly Income (₹)" value={form.income} onChange={v => set('income', v)} placeholder="e.g. 85000" type="number" />
        <InputField label="Age (years)" value={form.age} onChange={v => set('age', v)} placeholder="e.g. 32" type="number" />
        <SelectField label="Employment Type" value={form.employment} onChange={v => set('employment', v)} options={[
          { v: 'salaried', l: 'Salaried' }, { v: 'self', l: 'Self-Employed' }, { v: 'business', l: 'Business Owner' }
        ]} />
        <SelectField label="Loan Type" value={form.loanType} onChange={v => set('loanType', v)} options={[
          { v: 'home', l: 'Home Loan' }, { v: 'personal', l: 'Personal Loan' },
          { v: 'auto', l: 'Auto Loan' }, { v: 'education', l: 'Education Loan' }
        ]} />
        <InputField label="Existing Monthly Obligations (₹)" value={form.existing} onChange={v => set('existing', v)} placeholder="e.g. 15000" type="number" />
        <InputField label="Requested Loan Amount (₹)" value={form.loanAmount} onChange={v => set('loanAmount', v)} placeholder="e.g. 2500000" type="number" />
      </div>

      <button
        onClick={analyze}
        disabled={loading || !form.income || !form.age || !form.loanAmount}
        className="btn-primary w-full py-3.5 rounded-xl font-semibold text-white text-sm tracking-wide disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {loading ? (
          <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin-slow inline-block" />Analyzing with AI…</>
        ) : (
          <><SparkleIcon />Check Eligibility</>
        )}
      </button>

      {result && (
        <div className="space-y-4 animate-fade-in">
          <div className={`glass rounded-2xl p-5 border ${result.eligible ? 'border-emerald-400/30 glow-cyan' : 'border-rose-400/30'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${result.eligible ? 'bg-emerald-400/15' : 'bg-rose-400/15'}`}>
                {result.eligible ? '✅' : '❌'}
              </div>
              <div>
                <p className={`text-lg font-bold font-display ${result.eligible ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {result.eligible ? 'Loan Approved in Principle' : 'Not Eligible Currently'}
                </p>
                <p className="text-slate-400 text-sm">AI confidence score: {result.score}/100</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <StatCard label="Max Loan Amount" value={fmt(result.maxAmount)} accent="cyan" />
              <StatCard label="Interest Rate (p.a.)" value={`${result.interestRate}%`} accent="blue" />
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-400 uppercase tracking-widest mb-2 font-mono">AI Analysis</p>
              {result.reasons.map((r, i) => (
                <div key={i} className="flex gap-2 text-sm text-slate-300">
                  <span className="text-cyan-400 mt-0.5 shrink-0">›</span>
                  <span>{r}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function CreditScore() {
  const [form, setForm] = useState({ score: '', missedPayments: '0', creditAge: '', utilization: '', inquiries: '0' })
  const [result, setResult] = useState<CreditResult | null>(null)
  const [loading, setLoading] = useState(false)

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const analyze = useCallback(async () => {
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 1200))
    setResult(analyzeCreditScore({
      score: Number(form.score), missedPayments: Number(form.missedPayments),
      creditAge: Number(form.creditAge), utilization: Number(form.utilization),
      inquiries: Number(form.inquiries)
    }))
    setLoading(false)
  }, [form])

  const scoreVal = result?.score ?? 0
  const circumference = 2 * Math.PI * 54
  const offset = circumference - (scoreVal / 900) * circumference

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <InputField label="Current CIBIL Score (300–900)" value={form.score} onChange={v => set('score', v)} placeholder="e.g. 720" type="number" />
        <InputField label="Credit History Length (years)" value={form.creditAge} onChange={v => set('creditAge', v)} placeholder="e.g. 5" type="number" />
        <InputField label="Credit Utilization (%)" value={form.utilization} onChange={v => set('utilization', v)} placeholder="e.g. 28" type="number" />
        <SelectField label="Missed Payments (last 12 mo)" value={form.missedPayments} onChange={v => set('missedPayments', v)} options={[
          { v: '0', l: 'None' }, { v: '1', l: '1' }, { v: '2', l: '2' }, { v: '3', l: '3+' }
        ]} />
        <SelectField label="Recent Hard Inquiries" value={form.inquiries} onChange={v => set('inquiries', v)} options={[
          { v: '0', l: '0' }, { v: '1', l: '1' }, { v: '2', l: '2' }, { v: '3', l: '3' }, { v: '5', l: '4+' }
        ]} />
      </div>

      <button
        onClick={analyze}
        disabled={loading || !form.score || !form.creditAge || !form.utilization}
        className="btn-primary w-full py-3.5 rounded-xl font-semibold text-white text-sm tracking-wide disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {loading ? (
          <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin-slow inline-block" />Analyzing Credit Profile…</>
        ) : (
          <><SparkleIcon />Analyze Credit Score</>
        )}
      </button>

      {result && (
        <div className="space-y-4 animate-fade-in">
          <div className="glass rounded-2xl p-6">
            <div className="flex flex-col md:flex-row items-center gap-6 mb-6">
              <div className="relative shrink-0">
                <svg width="140" height="140" viewBox="0 0 140 140">
                  <circle cx="70" cy="70" r="54" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="12" />
                  <circle
                    className="score-ring"
                    cx="70" cy="70" r="54"
                    fill="none"
                    stroke={scoreColor(scoreVal)}
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    style={{ transition: 'stroke-dashoffset 1s cubic-bezier(0.4,0,0.2,1)' }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-black font-display" style={{ color: scoreColor(scoreVal) }}>{scoreVal}</span>
                  <span className="text-xs text-slate-400 font-mono">{result.rating}</span>
                </div>
              </div>
              <div className="flex-1 w-full">
                <p className="text-xs text-slate-400 uppercase tracking-widest mb-3 font-mono">Score Factors</p>
                <div className="space-y-3">
                  {result.factors.map((f, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className={`w-2 h-2 rounded-full shrink-0 ${f.impact === 'positive' ? 'bg-emerald-400' : f.impact === 'negative' ? 'bg-rose-400' : 'bg-amber-400'}`} />
                      <span className="text-sm text-slate-300 flex-1">{f.label}</span>
                      <span className="text-xs font-mono text-slate-400">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {result.advice.length > 0 && (
              <div className="bg-blue-500/8 border border-blue-400/15 rounded-xl p-4">
                <p className="text-xs text-blue-400 uppercase tracking-widest mb-3 font-mono">AI Recommendations</p>
                <div className="space-y-2">
                  {result.advice.map((a, i) => (
                    <p key={i} className="text-sm text-slate-300 flex gap-2">
                      <span className="text-blue-400 shrink-0">›</span>
                      {a}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function EmiCalculator() {
  const [form, setForm] = useState({ principal: '', rate: '', tenure: '', tenureUnit: 'years' })
  const [result, setResult] = useState<EmiResult | null>(null)

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const calc = useCallback(() => {
    const months = form.tenureUnit === 'years' ? Number(form.tenure) * 12 : Number(form.tenure)
    setResult(calcEmi(Number(form.principal), Number(form.rate), months))
  }, [form])

  const principalPct = result ? (result.totalPayment > 0 ? (Number(form.principal) / result.totalPayment) * 100 : 0) : 0
  const interestPct = 100 - principalPct

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <InputField label="Loan Principal (₹)" value={form.principal} onChange={v => set('principal', v)} placeholder="e.g. 2500000" type="number" />
        <InputField label="Annual Interest Rate (%)" value={form.rate} onChange={v => set('rate', v)} placeholder="e.g. 9.5" type="number" />
        <div className="space-y-1.5">
          <label className="text-xs text-slate-400 uppercase tracking-widest font-mono">Loan Tenure</label>
          <div className="flex gap-2">
            <input
              className="input-glass flex-1 px-4 py-3 rounded-xl text-sm"
              type="number"
              value={form.tenure}
              onChange={e => set('tenure', e.target.value)}
              placeholder="e.g. 20"
            />
            <select
              className="input-glass px-3 py-3 rounded-xl text-sm cursor-pointer"
              value={form.tenureUnit}
              onChange={e => set('tenureUnit', e.target.value)}
            >
              <option value="years">Years</option>
              <option value="months">Months</option>
            </select>
          </div>
        </div>
      </div>

      <button
        onClick={calc}
        disabled={!form.principal || !form.rate || !form.tenure}
        className="btn-primary w-full py-3.5 rounded-xl font-semibold text-white text-sm tracking-wide disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        <CalcIcon />Calculate EMI
      </button>

      {result && (
        <div className="space-y-4 animate-fade-in">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <StatCard label="Monthly EMI" value={fmt(result.emi)} accent="cyan" large />
            <StatCard label="Total Payment" value={fmt(result.totalPayment)} accent="blue" />
            <StatCard label="Total Interest" value={fmt(result.totalInterest)} accent="amber" />
          </div>

          <div className="glass rounded-2xl p-5">
            <p className="text-xs text-slate-400 uppercase tracking-widest mb-4 font-mono">Payment Breakdown</p>
            <div className="flex items-center gap-4 mb-3">
              <div className="flex-1">
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Principal — {principalPct.toFixed(1)}%</span>
                  <span>Interest — {interestPct.toFixed(1)}%</span>
                </div>
                <div className="h-3 rounded-full overflow-hidden flex" style={{ background: 'rgba(255,255,255,0.06)' }}>
                  <div style={{ width: `${principalPct}%`, background: 'linear-gradient(90deg, #22d3ee, #60a5fa)' }} className="transition-all duration-1000 rounded-l-full" />
                  <div style={{ width: `${interestPct}%`, background: 'linear-gradient(90deg, #f97316, #fbbf24)' }} className="transition-all duration-1000 rounded-r-full" />
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-400 uppercase tracking-widest mt-5 mb-3 font-mono">First 12 Months Schedule</p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-slate-500 border-b border-white/6">
                    <th className="text-left pb-2 font-mono">Month</th>
                    <th className="text-right pb-2 font-mono">Principal</th>
                    <th className="text-right pb-2 font-mono">Interest</th>
                    <th className="text-right pb-2 font-mono">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {result.breakdown.map(row => (
                    <tr key={row.month} className="border-b border-white/4 hover:bg-white/3 transition-colors">
                      <td className="py-1.5 text-slate-400 font-mono">{row.month}</td>
                      <td className="py-1.5 text-right text-cyan-400 font-mono">{fmt(row.principal)}</td>
                      <td className="py-1.5 text-right text-amber-400 font-mono">{fmt(row.interest)}</td>
                      <td className="py-1.5 text-right text-slate-300 font-mono">{fmt(row.balance)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function FinancialTips() {
  const [category, setCategory] = useState<keyof typeof AI_TIPS>('savings')
  const [loading, setLoading] = useState(false)
  const [tips, setTips] = useState<string[]>([])
  const [question, setQuestion] = useState('')

  const cats = [
    { k: 'savings', l: 'Savings Strategy', icon: '💰' },
    { k: 'investment', l: 'Investment', icon: '📈' },
    { k: 'debt', l: 'Debt Management', icon: '🎯' },
    { k: 'tax', l: 'Tax Planning', icon: '🏛️' },
  ] as const

  const loadTips = useCallback(async (cat: keyof typeof AI_TIPS) => {
    setCategory(cat)
    setLoading(true)
    setTips([])
    await new Promise(r => setTimeout(r, 900))
    setTips(AI_TIPS[cat])
    setLoading(false)
  }, [])

  const askQuestion = useCallback(async () => {
    if (!question.trim()) return
    setLoading(true)
    await new Promise(r => setTimeout(r, 1000))
    const q = question.toLowerCase()
    const cat: keyof typeof AI_TIPS =
      q.includes('invest') || q.includes('sip') || q.includes('mutual') ? 'investment' :
      q.includes('debt') || q.includes('loan') || q.includes('credit') ? 'debt' :
      q.includes('tax') || q.includes('80c') || q.includes('deduct') ? 'tax' : 'savings'
    setTips(AI_TIPS[cat])
    setCategory(cat)
    setLoading(false)
  }, [question])

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {cats.map(c => (
          <button
            key={c.k}
            onClick={() => loadTips(c.k)}
            className={`glass-light rounded-xl p-3.5 text-center transition-all border ${category === c.k ? 'tab-active' : 'border-transparent hover:border-white/10 hover:bg-white/5'}`}
          >
            <div className="text-2xl mb-1">{c.icon}</div>
            <div className="text-xs font-medium text-slate-300">{c.l}</div>
          </button>
        ))}
      </div>

      <div className="glass-light rounded-xl p-3 flex gap-2">
        <input
          className="input-glass flex-1 px-4 py-2.5 rounded-lg text-sm"
          placeholder="Ask AI anything… e.g. How do I build an emergency fund?"
          value={question}
          onChange={e => setQuestion(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && askQuestion()}
        />
        <button
          onClick={askQuestion}
          disabled={loading || !question.trim()}
          className="btn-primary px-4 py-2.5 rounded-lg text-sm font-medium text-white disabled:opacity-40 flex items-center gap-1.5"
        >
          <SparkleIcon />Ask
        </button>
      </div>

      {loading && (
        <div className="flex items-center gap-3 text-slate-400 text-sm py-4">
          <span className="w-4 h-4 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin-slow inline-block" />
          <span className="animate-pulse-slow">AI is generating personalized insights…</span>
        </div>
      )}

      {!loading && tips.length > 0 && (
        <div className="space-y-3 animate-fade-in">
          {tips.map((tip, i) => (
            <div
              key={i}
              className="glass-light rounded-xl p-4 border border-white/5 hover:border-cyan-400/15 transition-all"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <p className="text-sm text-slate-200 leading-relaxed">{tip}</p>
            </div>
          ))}
        </div>
      )}

      {!loading && tips.length === 0 && (
        <div className="text-center py-12 text-slate-500">
          <div className="text-4xl mb-3">🤖</div>
          <p className="text-sm">Select a category or ask a question to get AI-powered financial insights.</p>
        </div>
      )}
    </div>
  )
}

/* ─── Shared UI atoms ────────────────────────────────────── */
function InputField({ label, value, onChange, placeholder, type = 'text' }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs text-slate-400 uppercase tracking-widest font-mono">{label}</label>
      <input
        className="input-glass w-full px-4 py-3 rounded-xl text-sm"
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  )
}

function SelectField({ label, value, onChange, options }: {
  label: string; value: string; onChange: (v: string) => void
  options: { v: string; l: string }[]
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs text-slate-400 uppercase tracking-widest font-mono">{label}</label>
      <select
        className="input-glass w-full px-4 py-3 rounded-xl text-sm cursor-pointer"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
      </select>
    </div>
  )
}

function StatCard({ label, value, accent, large }: { label: string; value: string; accent: string; large?: boolean }) {
  const colors: Record<string, string> = {
    cyan: 'text-cyan-400', blue: 'text-blue-400', amber: 'text-amber-400', emerald: 'text-emerald-400'
  }
  return (
    <div className="glass-light rounded-xl p-4 border border-white/5">
      <p className="text-xs text-slate-400 font-mono uppercase tracking-widest mb-1">{label}</p>
      <p className={`font-bold font-display ${large ? 'text-2xl' : 'text-xl'} ${colors[accent] || 'text-white'}`}>{value}</p>
    </div>
  )
}

function SparkleIcon() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="shrink-0"><path d="M8 1l1.5 4.5L14 7l-4.5 1.5L8 13l-1.5-4.5L2 7l4.5-1.5L8 1z" fill="currentColor" /></svg>
}

function CalcIcon() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="shrink-0"><rect x="2" y="2" width="12" height="12" rx="2" stroke="currentColor" strokeWidth="1.5" /><path d="M5 6h2m4 0h-2m-4 4h6M5 6V8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
}

/* ─── Main App ───────────────────────────────────────────── */
export default function App() {
  const [tab, setTab] = useState<Tab>('eligibility')

  const tabs: { id: Tab; label: string; icon: string; short: string }[] = [
    { id: 'eligibility', label: 'Loan Eligibility', icon: '🏦', short: 'Eligibility' },
    { id: 'credit', label: 'Credit Analyzer', icon: '📊', short: 'Credit' },
    { id: 'emi', label: 'EMI Calculator', icon: '🧮', short: 'EMI' },
    { id: 'tips', label: 'AI Financial Tips', icon: '🤖', short: 'AI Tips' },
  ]

  return (
    <div className="mesh-bg min-h-screen" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-white/6">
        <div className="max-w-5xl mx-auto px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-base shadow-lg">
              🏦
            </div>
            <div>
              <h1 className="text-sm font-bold font-display gradient-text leading-tight">FinanceAI</h1>
              <p className="text-xs text-slate-500 leading-tight hidden sm:block">Powered by Claude AI</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse-slow" />
            <span className="text-xs text-slate-400 font-mono hidden sm:block">AI Online</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="max-w-5xl mx-auto px-4 pt-12 pb-8 text-center">
        <div className="inline-flex items-center gap-2 glass-light px-3 py-1.5 rounded-full text-xs text-cyan-400 font-mono mb-5 border border-cyan-400/15">
          <SparkleIcon />BFSI Intelligence Platform — India
        </div>
        <h2 className="text-4xl md:text-5xl font-black font-display gradient-text mb-4 leading-tight">
          AI Loan Eligibility<br className="hidden md:block" /> Checker
        </h2>
        <p className="text-slate-400 text-base max-w-xl mx-auto leading-relaxed">
          Instant, AI-powered financial analysis. Check loan eligibility, analyze credit health,
          calculate EMIs, and get personalized financial guidance — all in one platform.
        </p>
      </div>

      {/* Stats bar */}
      <div className="max-w-5xl mx-auto px-4 mb-8">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Loans Analyzed', value: '2.4M+' },
            { label: 'Avg Approval Rate', value: '73%' },
            { label: 'AI Accuracy', value: '94.7%' },
          ].map(s => (
            <div key={s.label} className="glass rounded-xl py-3 px-4 text-center border border-white/6">
              <p className="text-lg font-black font-display gradient-text">{s.value}</p>
              <p className="text-xs text-slate-500 font-mono">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main card */}
      <div className="max-w-5xl mx-auto px-4 pb-16">
        <div className="glass rounded-2xl border border-white/8 overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-white/6 overflow-x-auto">
            {tabs.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-5 py-4 text-sm font-medium whitespace-nowrap transition-all border-b-2 shrink-0 ${
                  tab === t.id
                    ? 'border-cyan-400 text-cyan-400 bg-cyan-400/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/3'
                }`}
              >
                <span>{t.icon}</span>
                <span className="hidden sm:inline">{t.label}</span>
                <span className="sm:hidden">{t.short}</span>
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="p-5 md:p-8">
            {tab === 'eligibility' && <LoanEligibility />}
            {tab === 'credit' && <CreditScore />}
            {tab === 'emi' && <EmiCalculator />}
            {tab === 'tips' && <FinancialTips />}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/6 py-6 text-center">
        <p className="text-xs text-slate-600 font-mono">
          FinanceAI © 2026 · Results are indicative only · Not financial advice · Powered by Claude AI
        </p>
      </footer>
    </div>
  )
}
